from frappe import _

def get_data():
	return [
		{
			"module_name": "Dcode",
			"type": "module",
			"label": _("Dcode")
		}
	]
